"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button"
import { ConfigDialog } from '@/components/config-dialog';
import { GameBoard } from '@/components/game-board';

export default function Home() {
  const [showConfig, setShowConfig] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-blue-500 to-purple-600 p-4">
      {!gameStarted ? (
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-8">Juego Interactivo</h1>
          <div className="space-y-4">
            <Button onClick={() => setGameStarted(true)} className="w-40">Jugar</Button>
            <Button onClick={() => setShowConfig(true)} variant="outline" className="w-40">Configuración</Button>
          </div>
        </div>
      ) : (
        <GameBoard onExit={() => setGameStarted(false)} />
      )}
      <ConfigDialog open={showConfig} onOpenChange={setShowConfig} />
    </div>
  );
}
"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Home, PlusCircle, BarChart2, FileText, Banknote, Newspaper, Package } from 'lucide-react';

export function GameBoard({ onExit }: { onExit: () => void }) {
  const [activeSection, setActiveSection] = useState('jugar');

  const menuItems = [
    { id: 'inicio', icon: Home, label: 'Inicio' },
    { id: 'crear', icon: PlusCircle, label: 'Crear' },
    { id: 'marketing', icon: BarChart2, label: 'Marketing' },
    { id: 'facturas', icon: FileText, label: 'Facturas' },
    { id: 'finanzas', icon: Banknote, label: 'Finanzas' },
    { id: 'noticias', icon: Newspaper, label: 'Noticias' },
    { id: 'productos', icon: Package, label: 'Productos' },
  ];

  return (
    <div className="w-full h-screen flex">
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="outline" className="absolute top-4 left-4">Menu</Button>
        </SheetTrigger>
        <SheetContent side="left">
          <nav className="flex flex-col space-y-4">
            {menuItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                className="justify-start"
                onClick={() => {
                  setActiveSection(item.id);
                  if (item.id === 'inicio') onExit();
                }}
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.label}
              </Button>
            ))}
          </nav>
        </SheetContent>
      </Sheet>

      <main className="flex-1 p-6">
        <h2 className="text-2xl font-bold mb-4">{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)}</h2>
        {activeSection === 'jugar' && (
          <div className="bg-gray-100 p-4 rounded-lg">
            <p>Aquí va el contenido del juego...</p>
          </div>
        )}
        {activeSection !== 'jugar' && (
          <div className="bg-gray-100 p-4 rounded-lg">
            <p>Contenido de la sección {activeSection}...</p>
          </div>
        )}
      </main>
    </div>
  );
}
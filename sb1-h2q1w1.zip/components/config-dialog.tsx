"use client"

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

export function ConfigDialog({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
  const [language, setLanguage] = useState('es');
  const [sound, setSound] = useState(true);
  const [music, setMusic] = useState(true);
  const [volume, setVolume] = useState([50]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Configuración</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="general">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="sound">Sonido</TabsTrigger>
            <TabsTrigger value="language">Idioma</TabsTrigger>
          </TabsList>
          <TabsContent value="general">
            <div className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="sound">Sonido</Label>
                <Switch id="sound" checked={sound} onCheckedChange={setSound} />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="music">Música</Label>
                <Switch id="music" checked={music} onCheckedChange={setMusic} />
              </div>
            </div>
          </TabsContent>
          <TabsContent value="sound">
            <div className="space-y-4 mt-4">
              <Label>Volumen</Label>
              <Slider
                value={volume}
                onValueChange={setVolume}
                max={100}
                step={1}
              />
            </div>
          </TabsContent>
          <TabsContent value="language">
            <div className="space-y-4 mt-4">
              <Label>Idioma</Label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full p-2 border rounded"
              >
                <option value="es">Español</option>
                <option value="en">English</option>
              </select>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}